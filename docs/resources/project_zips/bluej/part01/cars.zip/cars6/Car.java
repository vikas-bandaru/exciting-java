/**
   A simulated car that consumes fuel as it drives.
*/
public class Car
{
    private double kmsDriven;
    private double fuelInTank;
    private double kmsPerLitre;


    /**
       Constructs a car with a given fuel efficiency.
       @param kmpl the kilometers per litre of this car
    */
    public Car(double kmpl)
    {
        kmsDriven = 0;
        fuelInTank = 0;
        kmsPerLitre = kmpl;
    }


    // Your turn

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    /**
       Gets the current amount of fuel in the tank of this car.
       @return the current fuel level
    */
    public double getFuelInTank()
    {
        return fuelInTank;
    }

    /**
       Drives this car by a given distance.
       @param distance the distance to drive
    */
    public void drive(double distance)
    {
        kmsDriven = kmsDriven + distance;
        double fuelConsumed = distance / kmsPerLitre;
        fuelInTank = fuelInTank - fuelConsumed;
    }

    /**
       Gets the current mileage of this car.
       @return the total number of kilometers driven
    */
    public double getKmsDriven()
    {
        return kmsDriven;
    }
}

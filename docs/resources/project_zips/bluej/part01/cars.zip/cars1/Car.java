public class Car
{
    private double kmsDriven;
    private double fuelInTank;

    public void drive(double distance)
    {
        kmsDriven = kmsDriven + distance;
    }

    public void addGas(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    // More methods...
}

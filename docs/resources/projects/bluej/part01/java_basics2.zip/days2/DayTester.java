public class DayTester
{
    public static void main(String[] args)
    {
        Day today = new Day(2024, 6, 5); // June 5, 2024
        today.addDays(30);

        System.out.println(today.getYear());
        System.out.println("Expected: 2024");
        System.out.println(today.getMonth());
        System.out.println("Expected: 7");
        System.out.println(today.getDayOfMonth());
        System.out.println("Expected: 5");
        System.out.println(today.daysFrom(today));
        System.out.println("Expected: 0");
    }
}

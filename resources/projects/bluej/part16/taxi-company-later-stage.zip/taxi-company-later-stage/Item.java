/**
 * An item in the city.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 */

public interface Item
{
    public Location getLocation();
}

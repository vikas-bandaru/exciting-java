// BlueJ project: cars5

// Complete the second constructor of this class.

public class Car
{
    private double distanceDriven;
    private double fuelInTank;
    private double mileage;
    private Picture pic;

    public Car(double kmpl)
    {
        distanceDriven = 0;
        fuelInTank = 0;
        mileage = kmpl;
        pic = new Picture("car.jpg");
        pic.draw();
    }

    public Car(double mpl, String pictureFile)
    {
        // TODO: Complete this constructor
    }

    public void drive(double distance)
    {
        distanceDriven = distanceDriven + distance;
        double fuelConsumed = distance / mileage;
        fuelInTank = fuelInTank - fuelConsumed;
        int pixelsPerKm = 10;
        pic.translate(distance * pixelsPerKm, 0);
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    public double getDistanceDriven()
    {
        return distanceDriven;
    }

    public double getFuelInTank()
    {
        return fuelInTank;
    }

}

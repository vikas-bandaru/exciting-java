// TODO: Decide whether this is a compile-time or run-time error.

public class CompileOrRunTime
{
    public static void main(String[] args)
    {
        System.out.print("My lucky number is");
        System.out.println(3 + 4 + 5);
    }
}

public class Car
{
    private double distanceDriven;
    private double fuelInTank;
    private Picture pic;

    public Car() // Discussed later
    {
        distanceDriven = 0;
        fuelInTank = 0;
        pic = new Picture("car.jpg");
        pic.draw();
    }

    public void drive(double distance)
    {
        distanceDriven = distanceDriven + distance;
        int pixelsPerKm = 10;
        pic.translate(distance * pixelsPerKm, 0);
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    // Write Accessor methods... for distanceDriven & fuelInTank

}

public class Error1
{
    public static void main(String[] args)
    {
        System.ouch.println("Hello, World!");
    }
}

public class Car
{
    private double kmsDriven;
    private double fuelInTank;
    private Picture pic;

    public Car() // Discussed later
    {
        kmsDriven = 0;
        fuelInTank = 0;
        pic = new Picture("car.jpg");
        pic.draw();
    }

    public void drive(double distance)
    {
        kmsDriven = kmsDriven + distance;
        int pixelsPerKm = 10;
        pic.translate(distance * pixelsPerKm, 0);
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    // More methods ...

}

public class DaysAlivePrinter
{
    public static void main(String[] args)
    {
        Day birthDay = ...;
        Day lastDay = ...;
        
        System.out.print("LastDay: ");
        System.out.println(lastDay.toString());
        
        int daysAlive = lastDay.daysFrom(birthDay);
        
        System.out.print("Days alive: ");
        System.out.println(daysAlive);
    }
}

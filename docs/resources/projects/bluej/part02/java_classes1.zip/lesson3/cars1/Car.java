public class Car
{
    // Fields: distance driven, fuel in tank

    // Methods: drive, addFuel

}

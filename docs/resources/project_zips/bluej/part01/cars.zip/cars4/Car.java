public class Car
{
    private double kmsDriven;
    private double fuelInTank;
    private double kmsPerLitre;

    public Car()
    {
        kmsDriven = 0;
        fuelInTank = 0;
        kmsPerLitre = 50;
    }

    public void drive(double distance)
    {
        kmsDriven = kmsDriven + distance;
        double fuelConsumed = distance / kmsPerLitre;
        fuelInTank = fuelInTank - fuelConsumed;
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    public double getKmsDriven()
    {
        return kmsDriven;
    }

    public double getFuelInTank()
    {
        return fuelInTank;
    }
}

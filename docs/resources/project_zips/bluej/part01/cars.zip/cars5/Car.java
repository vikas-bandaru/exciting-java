// BlueJ project: cars5

// Complete the second constructor of this class.

public class Car
{
    private double kmsDriven;
    private double fuelInTank;
    private double kmsPerLitre;
    private Picture pic;

    public Car(double kmpl)
    {
        kmsDriven = 0;
        fuelInTank = 0;
        kmsPerLitre = kmpl;
        pic = new Picture("car.jpg");
        pic.draw();
    }

    public Car(double kmpl, String pictureFile)
    {
        // TODO: Complete this constructor
    }

    public void drive(double distance)
    {
        kmsDriven = kmsDriven + distance;
        double fuelConsumed = distance / kmsPerLitre;
        fuelInTank = fuelInTank - fuelConsumed;
        int pixelsPerKm = 10;
        pic.translate(distance * pixelsPerKm, 0);
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    public double getKmsDriven()
    {
        return kmsDriven;
    }

    public double getFuelInTank()
    {
        return fuelInTank;
    }
}
public class Car
{
    private double distanceDriven;
    private double fuelInTank;
    // field for mileage
    

    public Car()
    {
        distanceDriven = 0;
        fuelInTank = 0;
        // initialize mileage
	
    }

    public void drive(double distance)
    {
        distanceDriven = distanceDriven + distance;
        // update fuel in tank based on distanceDriven
	
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    public double getDistanceDriven()
    {
        return distanceDriven;
    }

    public double getFuelInTank()
    {
        return fuelInTank;
    }

}

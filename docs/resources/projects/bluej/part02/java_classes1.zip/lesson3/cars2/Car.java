public class Car
{
    private double distanceDriven;
    private double fuelInTank;
    private Picture pic;

    public Car() // Discussed later
    {
        distanceDriven = 0;
        fuelInTank = 0;
        pic = new Picture("car.jpg");
        pic.draw();
    }

    public void drive(double distance)
    {
        distanceDriven = distanceDriven + distance;
        // make car move with translate method
	
    }

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    // More methods ...

}

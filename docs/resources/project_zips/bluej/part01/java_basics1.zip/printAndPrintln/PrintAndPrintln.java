// TODO: Print 3 with the print method, 
// then 4 + 5 with the println method.
// Complete the program, compile, run, and observe.

public class PrintAndPrintln
{
    public static void main(String[] args)
    {
        System.out.print(  );
        System.out.println(  );
    }
}

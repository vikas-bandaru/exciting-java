// BlueJ project: cars4

// Write a tester program that prints the actual and
// expected fuel level after the given method calls.

public class CarTester
{
    public static void main(String[] args)
    {
        Car car = new Car();

        // TODO: Add 20 litres and drive 100 kilometers

        // TODO: Print actual and expected fuel level

    }
}

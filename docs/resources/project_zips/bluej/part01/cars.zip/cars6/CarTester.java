public class CarTester
{
    public static void main(String[] args)
    {
        Car myCar = new Car(20);

        myCar.addFuel(20);
        myCar.drive(100);
        System.out.println(myCar.getFuelInTank());
        System.out.println("Expected: 15");
    }
}
public class PersonDemo 
{
    public static void main(String[] args)
    {
        // create 3 Person objects
        
        // add 2 Persons to first Person

        // unfriend 2nd Person from 1st Person

        // print all friends of each object along with expected
	
    }
}
/**
   A simulated car that consumes fuel as it drives.
*/
public class Car
{
    private double distanceDriven;
    private double fuelInTank;
    private double mileage;


    /**
       Constructs a car with a given fuel efficiency.
       @param kmpl the kilometers per litre of this car
    */
    public Car(double kmpl)
    {
        milesDriven = 0;
        fuelInTank = 0;
        milesPerLitre = kmpl;
    }


    // Your turn

    public void addFuel(double amount)
    {
        fuelInTank = fuelInTank + amount;
    }

    /**
       Gets the current amount of fuel in the tank of this car.
       @return the current fuel level
    */
    public double getFuelInTank()
    {
        return fuelInTank;
    }

    /**
       Drives this car by a given distance.
       @param distance the distance to drive
    */
    public void drive(double distance)
    {
        distanceDriven = distanceDriven + distance;
        double fuelConsumed = distance / mileage;
        fuelInTank = fuelInTank - fuelConsumed;
    }

    /**
       Gets the current mileage of this car.
       @return the total number of kilometers driven
    */
    public double getDistanceDriven()
    {
        return distanceDriven;
    }
}
